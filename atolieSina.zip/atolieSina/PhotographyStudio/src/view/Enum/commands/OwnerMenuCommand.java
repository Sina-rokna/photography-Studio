package view.Enum.commands;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public enum OwnerMenuCommand{
    ADD_IMAGE("add\\s+image\\s+(?<title>[^ ]+)\\s+(?<photographerArtist>[^ ]+)\\s+(?<locationOfWork>[^ ]+)\\s+(?<price>[^ ]+)\\s+(?<number>[^ ]+)\\s+(?<sizeOfImage>[^ ]+)"),
    ADD_CLIP("add\\s+clip\\s+(?<title>[^ ]+)\\s+(?<photographerArtist>[^ ]+)\\s+(?<locationOfWork>[^ ]+)\\s+(?<price>[^ ]+)\\s+(?<number>[^ ]+)\\s+(?<duration>[^ ]+)\\s+(?<resolution>[^ ]+)");

    public String regex;
    OwnerMenuCommand(String regex) {
        this.regex = regex;
    }

    public static Matcher getMatcher(String input, OwnerMenuCommand mainRegex) {
        Matcher matcher = Pattern.compile(mainRegex.regex).matcher(input);
        if (matcher.matches())
            return matcher;
        return null;
    }
}
