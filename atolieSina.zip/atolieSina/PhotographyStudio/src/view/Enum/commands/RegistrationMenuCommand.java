package view.Enum.commands;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public enum RegistrationMenuCommand {
    REGISTER_CUSTOMER("register\\s+(?<username>[^ ]+)\\s+(?<password>[^ ]+)"),
    PASSWORD_VALID("(?<password>[A-Za-z0-9_]+)"),
    REGISTER_OWNER("register\\s+(?<username>[^ ]+)\\s+(?<password>[^ ]+)\\s+as\\s+(?<role>.+)"),
    LOGIN("login\\s+(?<username>[a-zA-Z0-9_]+)\\s+(?<password>[a-zA-Z0-9_]+)");
    public String regex;
    RegistrationMenuCommand(String regex) {
        this.regex = regex;
    }

    static {
        for (RegistrationMenuCommand command : values()) {
            Pattern.compile(command.regex);
        }
    }
    public static Matcher getMatcher(String input, RegistrationMenuCommand mainRegex) {
        Matcher matcher = Pattern.compile(mainRegex.regex).matcher(input);
        if (matcher.matches())
            return matcher;
        return null;
    }
}
