package view.Enum.commands;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum CustomerMenuCommand {
    BUY_PRODUCTS("buy\\s+product\\s+(?<title>[^ ]+)\\s+(?<number>[^ ]+)"),///////////////
    INCREASE_BALANCE("increase\\s+balance\\s+(?<number>[^ ]+)"),//////////////////////////////
    SHOW_ALL_PRODUCTS("show all type of clips and videos"),///////////////////
    SHOW_USER_BILL("show my bill"),
    SHOW_BALANCE("show my balance");
    public String regex;

    CustomerMenuCommand(String regex) {
        this.regex = regex;
    }
    public static Matcher getMatcher(String input,CustomerMenuCommand mainRegex) {
        Matcher matcher = Pattern.compile(mainRegex.regex).matcher(input);
        if (matcher.matches())
            return matcher;
        return null;
    }
}
