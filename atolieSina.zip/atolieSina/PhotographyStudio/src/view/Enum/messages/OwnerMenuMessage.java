package view.Enum.messages;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum OwnerMenuMessage {
    ADD_CLIP("add\\s+clip\\s+(?<title>[^ ]+)\\s+(?<locationOfWork>[^ ]+\\s+(?<photographerArtist>[^ ]+)\\s+(?<price>[^ ]+)\\s+(?<duration>[^ ]+)\\s+(?<resolution>[^ ]+)"),
    ADD_IMAGE("add\\s+image\\s+(?<title>[^ ]+)\\s+(?<locationOfWork>[^ ]+\\s+(?<photographerArtist>[^ ]+)\\s+(?<price>[^ ]+)\\s+(?<imageSize>[^ ]+)"),
    SUCCESS;
    public String regex;
    OwnerMenuMessage(String regex) {
        this.regex = regex;
    }
    OwnerMenuMessage() {
    }
    public static Matcher getMatcher(String input, OwnerMenuMessage mainRegex) {
        Matcher matcher = Pattern.compile(mainRegex.regex).matcher(input);
        if (matcher.matches())
            return matcher;
        return null;
    }

}
