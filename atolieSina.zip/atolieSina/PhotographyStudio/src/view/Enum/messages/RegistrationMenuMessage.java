package view.Enum.messages;

public enum RegistrationMenuMessage {
    SUCCESS,
    USERNAME_NOT_EXISTS,
    USERNAME_EXISTS,
    ROLE_NOT_EXISTS,
    INCORRECT_PASSWORD,
    LOGIN_SUCCESSFUL_AS_OWNER,
    LOGIN_SUCCESSFUL_AS_CUSTOMER,
}
