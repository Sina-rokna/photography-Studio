package view.Enum.messages;

public enum CustomerMenuMessage {
    SUCCESS,
    TITLE_NOT_EXISTS,
    INSUFFICIENT_BALANCE,
    INSUFFICIENT_NUMBER,

}
