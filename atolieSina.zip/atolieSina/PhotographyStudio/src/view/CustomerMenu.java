package view;
import controller.CustomerMenuController;
import model.Studio;
import model.product.Clips;
import model.product.Products;
import model.user.Customer;
import view.Enum.commands.CustomerMenuCommand;
import view.Enum.messages.CustomerMenuMessage;
import java.util.Scanner;
import java.util.regex.Matcher;
public class CustomerMenu {
    public static void run(Scanner scanner) {
        while (true) {
            String command = scanner.nextLine().trim();
            Matcher matcher;
            if (command.equals("logout")) {
                System.out.println("We are currently on the register menu!");
                break;
            }else if (command.equals("help"))
                DescriptionOfMenus.CustomerMenuDescription();
            else if((matcher = CustomerMenuCommand.getMatcher(command, CustomerMenuCommand.BUY_PRODUCTS)) != null)
                buyProducts(matcher);
             else if ((matcher = CustomerMenuCommand.getMatcher(command, CustomerMenuCommand.INCREASE_BALANCE)) != null) {
                int x = 1;
                if (x != 0){
                increase(matcher);
                x --;}
            }  else if ((matcher = CustomerMenuCommand.getMatcher(command, CustomerMenuCommand.SHOW_ALL_PRODUCTS)) != null)
                showAllProducts(matcher);
              else if ((matcher = CustomerMenuCommand.getMatcher(command, CustomerMenuCommand.SHOW_USER_BILL)) != null)
                showUserBill(matcher);
              else if((matcher = CustomerMenuCommand.getMatcher(command, CustomerMenuCommand.SHOW_BALANCE)) != null)
                showUserBalance(matcher);
              else {
                System.out.println("invalid command!");
            }
        }
    }
    private static void buyProducts(Matcher matcher) {
        String title = matcher.group("title");
        String number = matcher.group("number");
        CustomerMenuMessage message = CustomerMenuController.buyProduct(title, number);
        switch (message) {
            case TITLE_NOT_EXISTS:
                System.out.println("there isn't product with this information");
                break;
            case INSUFFICIENT_NUMBER:
                System.out.println("not enough time for our studio for your order. please decrease your order.");
                break;
            case INSUFFICIENT_BALANCE:
                System.out.println("you don't have Insufficient inventory");
                break;
            case SUCCESS:
                System.out.println("reserving the order(s) successfully");
                break;
            default:
                break;
        }
    }
    private static void increase(Matcher matcher) {
        String number = matcher.group("number");
        CustomerMenuMessage message = CustomerMenuController.increase(number);
        switch (message) {
            case SUCCESS:
            {System.out.println("increasing the inventory successfully");
                break;}
            default:
                break;
        }

    }
    private static void showUserBill(Matcher matcher) {
        int number = 1;
        for (Products product : ((Customer) Studio.getCurrentUser()).getBoughtProducts()) {
            System.out.println(number + "-" + product.getTitle() + " | Artist: " + product.getPhotographerArtist() + " | Price: "
                    + product.getPrice());
            number++;
        }
    }
    private static void showUserBalance(Matcher matcher){
       System.out.println (((Customer) Studio.getCurrentUser()).getBalance() + " Toman.");
    }
     private static void showAllProducts(Matcher matcher) {
        for (Products product : Studio.getAllProducts()) {
                 System.out.println(product.chapgar());
                if(product instanceof Clips)
                    System.out.println(product);
        }
    }
}
