package view;
import controller.RegistrationMenuController;
import view.Enum.commands.RegistrationMenuCommand;
import view.Enum.messages.RegistrationMenuMessage;
import java.util.Scanner;
import java.util.regex.Matcher;

import static view.DescriptionOfMenus.MainMenuDescription;
import static view.DescriptionOfMenus.RegistrationMenuDescription;

public class RegisterMenu {
    public static void run(){
        Scanner scanner = new Scanner(System.in);
        while(true){
            Matcher matcher;
            String command = scanner.nextLine();
            if(command.equals("exit")){
                System.out.println("are you sure?");
                exit();
            }
            else if(command.equals("logout")){
                System.out.println("are you sure?");
                exit();
            }else if (command.equals("help"))
                RegistrationMenuDescription();
            else if(command.equals("about studio?"))
                MainMenuDescription();
            else if(command.equals("send feedback"))
                sendFeedback();
             else if((matcher = RegistrationMenuCommand.getMatcher(command, RegistrationMenuCommand.REGISTER_CUSTOMER)) != null)
                checkRegisterCustomer(matcher);
            else if((matcher = RegistrationMenuCommand.getMatcher(command, RegistrationMenuCommand.REGISTER_OWNER)) != null)
                checkRegisterOwner(matcher);
            else if((matcher = RegistrationMenuCommand.getMatcher(command, RegistrationMenuCommand.LOGIN)) != null)
                checkLogin(matcher,scanner);
            else
                System.out.println("invalid commands!");
        }
    }

    private static void sendFeedback(){

    }
    private static void exit(){
        Scanner scanner = new Scanner(System.in);
        String command = scanner.nextLine();
        if(command.equals("yes"))
            System.exit(0);
        if(command.equals("no"))
            System.out.println("ok:) keep on:");
        else
            System.out.println("invalid commands!");
    }
    public static void checkRegisterCustomer(Matcher matcher) {
        String username = matcher.group("username");
        String password = matcher.group("password");
        RegistrationMenuMessage message = RegistrationMenuController.checkRegisterCustomer(username, password);
        checkRegister(message);
    }
    private static void checkRegister(RegistrationMenuMessage message) {
        switch (message) {
            case USERNAME_EXISTS:
                System.out.println("a user exists with this username.\nregister with a new username please!");
                break;
            case SUCCESS:
                System.out.println("register successful! congratulation.");
                break;
            default:
                break;
        }
    }

    public static void checkRegisterOwner(Matcher matcher) {
        String username = matcher.group("username");
        String password = matcher.group("password");
        String role = matcher.group("role");
        RegistrationMenuMessage message = RegistrationMenuController.checkRegisterOwner(username, password , role);
        /// the below function is from the up function("checkRegister")
        checkRegister(message);
    }
    private static Scanner scanner = new Scanner(System.in);
    private static Matcher matcher;
    public static void checkLogin(Matcher matcher, Scanner scanner){
        String username = matcher.group("username");
        String password = matcher.group("password");
        RegistrationMenuMessage message = RegistrationMenuController.checkLogin(username , password);
        switch (message){
            case USERNAME_NOT_EXISTS:
                System.out.println("no user exits with this username!");
                break;
            case INCORRECT_PASSWORD:
                System.out.println("incorrect password :( ");
                break;
            case LOGIN_SUCCESSFUL_AS_CUSTOMER:
                System.out.println("login to customer menu successful :)\nyou are currently on the customer menu!");
                CustomerMenu.run(scanner);
                break;
            case LOGIN_SUCCESSFUL_AS_OWNER:
                System.out.println("login to owner menu successful :)\nyou are currently on the owner menu!");
                OwnerMenu.run(scanner);
                break;
            default:
                break;
        }
    }
}
