package view;
import controller.OwnerMenuController;
import view.Enum.commands.OwnerMenuCommand;
import view.Enum.messages.OwnerMenuMessage;
import java.util.Scanner;
import java.util.regex.Matcher;
public class OwnerMenu {
    public static void run(Scanner scanner){
        while(true){
                String command = scanner.nextLine().trim();
                Matcher matcher;
                if(command.equals("logout")){
                    System.out.println("We are currently on the register menu!");
                    break;
                }else if (command.equals("help"))
                    DescriptionOfMenus.OwnerMenuDescription();
                else if((matcher = OwnerMenuCommand.getMatcher(command, OwnerMenuCommand.ADD_CLIP)) != null){
                    addClip(matcher);
                }else if((matcher = OwnerMenuCommand.getMatcher(command, OwnerMenuCommand.ADD_IMAGE)) != null){
                    addImage(matcher);
                }else
                    System.out.println("Invalid Command!");
            }
    }
    public static void addClip(Matcher matcher){
        String title = matcher.group("title");
        String locationOfWork = matcher.group("locationOfWork");
        String photographerArtis = matcher.group("photographerArtist");
        String price = matcher.group("price");
        String number = matcher.group("number");
        String duration = matcher.group("duration");
        String resolution = matcher.group("resolution");
        OwnerMenuMessage message = OwnerMenuController.addClip(title , locationOfWork, photographerArtis, price,number, duration, resolution);
        switch (message){
            case SUCCESS:
            { System.out.println("add clip successful!");
                break;}
            default:
                break;
        }
    }
    public static void addImage(Matcher matcher){
    String title = matcher.group("title");
    String locationOfWork = matcher.group("locationOfWork");
    String photographerArtis = matcher.group("photographerArtist");
    String price = matcher.group("price");
    String number = matcher.group("number");
    String sizeOfImage = matcher.group("sizeOfImage");
    OwnerMenuMessage message = OwnerMenuController.addImage(title , locationOfWork , photographerArtis , price , number , sizeOfImage);
    switch (message){
        case SUCCESS:
            System.out.println("add image successful!");
            break;
        default:
            break;
        }
    }
}
