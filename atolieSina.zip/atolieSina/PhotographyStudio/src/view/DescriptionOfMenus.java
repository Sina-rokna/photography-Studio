package view;

public class DescriptionOfMenus {
    public static void CustomerMenuDescription() {
        System.out.println("Hello and welcome to the Customer Menu!\n" +
                "In this menu, you can reserve the type and number of clips or images you want.\n" +
                " You also have the option to charge your account if needed. Additionally, you can check your inventory.\n" +
                "We are committed to updating this app with more features to provide you with better moments.\n" +
                "Below, you can find some information about the commands used in this menu:\n" + "\u001B[34m" +
                "1. To buy product:  buy + product + the complete title of desire product + number of that\n" +
                "2. To increase balance:  increase + balance + amount of increasing\n" +
                "3. To show products of studio:  show all type of clips and videos\n" +
                "4. To show your bill:  show my bill\n" +
                "5. To show your balance:  show my balance\n"
                + "\u001B[0m");
    }

    public static void MainMenuDescription() {
        System.out.println("\u001B[33m" + "Welcome to \"Sina\" Photography Studio, where every click captures the essence of timeless beauty and emotion.\n" +
                "Step into our elegantly designed studio, bathed in soft, natural light, and adorned with vintage-inspired decor that exudes an aura of creativity and sophistication.\n" +
                "Our team of talented photographers possesses an unparalleled passion for storytelling through images, ensuring that every moment is immortalized with artistry and finesse.\n" +
                "From intimate portraits to grand celebrations, \"Sina\" Photography Studio specializes in capturing the magic of life's most precious moments.\n" +
                "Our state-of-the-art equipment and innovative techniques guarantee stunning, high-quality photographs that will leave you breathless.\n" +
                "Whether it's a wedding, a family portrait, or a professional headshot, \"Sina\" Photography Studio is dedicated to creating visual masterpieces that will be cherished for generations to come.\n" +
                "Step into our world, and let us turn your moments into memories that last a lifetime." + "\u001B[0m");
    }

    public static void OwnerMenuDescription() {
        System.out.println("Welcome to the Owner Menu!\n" +
                "In this section, you can easily add clips and videos along with their information\n" +
                "to your studio for your customers. Our goal is to enhance your ability to manage\n" +
                "your media content, providing you with a more comfortable and efficient access.\n" +"\u001B[34m"+
                "We are continuously working to improve this feature for an even better experience. use this command in this menu\n" +
                "1. To add image:  add + image + type of mentioned image + photographer artist's name + location +\n" +
                 "price + number of clip such customers can reserve+ sizeOfImage\n" +
                "2. To add clip: add + clip + type of mentioned clip + photographer artist's name + location\n" +
                 "+ price + number of clip such customer can reserve + duration of clip + resolution of provided clip"+ "\u001B[0m");
    }
    public static void RegistrationMenuDescription(){
        System.out.println("Welcome to our App!\n" +
                "In this menu, you can easily register as a customer or owner, and also login using the following commands:\n" +"\u001B[34m"+
                "1. To register as a customer:  register + username + password.\n" +
                "2. To register as an owner:  register + username+ as + role.\n" +
                "3. To login:  login + username + password\n" +
                "Our app is designed to streamline the registration and login processes, providing a secure\n" +
                "and efficient way for users to access the platform." + "\u001B[0m");
    }
}

