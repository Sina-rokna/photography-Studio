package controller;
import model.Studio;
import model.user.Customer;
import model.user.Owner;
import model.user.Role;
import view.Enum.messages.RegistrationMenuMessage;

public class RegistrationMenuController {
    public static RegistrationMenuMessage checkRegisterCustomer(String username, String password){
        if (Studio .getUser(username) != null) {
            return RegistrationMenuMessage.USERNAME_EXISTS;
        }
        Customer customer = new Customer(username, password);
        System.out.println("user Id: " + customer.getLastUserId() + "\nplease don't forget that! :)");
        Studio.addUser(customer);
        return RegistrationMenuMessage.SUCCESS;
    }
    public static RegistrationMenuMessage checkRegisterOwner(String username, String password, String role) {
        if (Studio.getUser(username) != null)
            return RegistrationMenuMessage.USERNAME_EXISTS;
        Role tempRole = null;
        if (!role.equals("financial manager") & role.equals("department manager") & !role.equals("photographer"))
            return RegistrationMenuMessage.ROLE_NOT_EXISTS;
        else if (role.equals("financial manager"))
            tempRole = Role.FINANCIAL_MANAGEMENT;
        else if (role.equals("department manager"))
            tempRole = Role.DEPARTMENT_MANAGER;
        else if(role.equals("photographer"))
            tempRole = Role.PHOTOGRAPHER;

        Owner owner = new Owner(username, password, tempRole);
        System.out.println("user Id: " + Owner.getLastUserId() + "\nplease don't forget that! :)");
        Studio.addUser(owner);
        return RegistrationMenuMessage.SUCCESS;
    }
    public static RegistrationMenuMessage checkLogin(String username, String password) {
        if (Studio.getUser(username) == null)
            return RegistrationMenuMessage.USERNAME_NOT_EXISTS;
        else if (!(Studio.getUser(username).getPassword().equals(password)))
            return RegistrationMenuMessage.INCORRECT_PASSWORD;
        else if (Studio.getUser(username) instanceof Owner) {
            Studio.setCurrentUser(Studio.getUser(username));
            return RegistrationMenuMessage.LOGIN_SUCCESSFUL_AS_OWNER;
        }
        else if(Studio.getUser(username)instanceof Customer){
            Studio.setCurrentUser(Studio.getUser(username));
            return RegistrationMenuMessage.LOGIN_SUCCESSFUL_AS_CUSTOMER;
        }
        return null;
    }
}
