package controller;
import model.Studio;
import model.product.Products;
import model.user.Customer;
import view.Enum.messages.CustomerMenuMessage;

public class CustomerMenuController {
    public static CustomerMenuMessage buyProduct(String title, String number) {
        Customer customer = (Customer) Studio.getCurrentUser();
        int tempNumber = Integer.parseInt(number);
        Products product;
        if ((product = Studio.getProduct(title)) == null)
            return CustomerMenuMessage.TITLE_NOT_EXISTS;
         else if (product.getNumber() < tempNumber)
            return CustomerMenuMessage.INSUFFICIENT_NUMBER;
         else if (customer.getBalance() < (tempNumber * product.getPrice()))
            return CustomerMenuMessage.INSUFFICIENT_BALANCE;
        customer.getBoughtProducts().add(product);
        customer.setBalance(customer.getBalance() - (tempNumber * product.getPrice()));
        product.setNumber(product.getNumber() - tempNumber);
        return CustomerMenuMessage.SUCCESS;
    }
    public static CustomerMenuMessage increase(String number){
        int tmpNumber = Integer.parseInt(number);
        Customer customer = (Customer) Studio.getCurrentUser();
        customer.setBalance(customer.getBalance() + tmpNumber);
        return CustomerMenuMessage.SUCCESS;
    }
}
