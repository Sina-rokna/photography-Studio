package controller;

import model.Studio;
import model.product.Clips;
import model.product.Images;
import view.Enum.messages.OwnerMenuMessage;

public class OwnerMenuController{
    public static OwnerMenuMessage addClip(String title , String locationOfWork , String photographerArtis , String price, String number , String duration , String resolution){
        Clips clip = new Clips(title , locationOfWork , photographerArtis , Integer.parseInt(price), Integer.parseInt(number),duration , resolution);
        Studio.addProduct(clip);
        return OwnerMenuMessage.SUCCESS;
    }
    public static OwnerMenuMessage addImage(String title, String locationOfWork, String photographerArtist, String number, String price, String sizeOfImage) {
        Images image = new Images(title , locationOfWork , photographerArtist , Integer.parseInt(price), Integer.parseInt(number), sizeOfImage);
        Studio.addProduct(image);
        return OwnerMenuMessage.SUCCESS;
    }
}
