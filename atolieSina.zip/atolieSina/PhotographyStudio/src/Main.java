import view.RegisterMenu;

public class Main {
    public static void main(String args[]){
        System.out.println("\u001B[31m%@@=...:@@@*    #@=                             \n" +
                        "\u001B[32m*@*        @@*                                   \n" +
                        "\u001B[33m.@@#-            #@=   @%+@@@@@@#     #@@@#@@@%. \n" +
                        "\u001B[34m:%@@@@#++.      #@=   @@@-   -@@+   @@+     #@% \n" +
                        "\u001B[35m     .++%@@@:   #@=   @@.     *@@        .-=*@@ \n" +
                        "\u001B[36m#@         -@@   #@=   @@      *@@   *@@#***.-@@ \n" +
                        "\u001B[37m%@%.       +@@   #@=   @@      *@@  +@%      #@@ \n" +
                        "\u001B[31m  .%@@@@@@@@@+    #@=   @@      *@@   %@@%=#@%*@" + "\u001B[0m");
        System.out.println("welcome to your studio!\nplease register or login :)" );
        System.out.println("use (help) command when you were confused!!");
        RegisterMenu.run();
        System.out.println("I wish good time for you.");
    }
}
