package model.user;

public class Owner extends User{
    private Role role;
    private static int lastOwnerId;
    static{
        lastOwnerId = 0;
    }
    public Owner(String username , String password , Role role){
        super(username , password);
        this.role = role;
        this.lastOwnerId = lastOwnerId;
        lastOwnerId++;
    }
}
