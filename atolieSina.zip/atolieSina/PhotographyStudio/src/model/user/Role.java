package model.user;

public enum Role {
    FINANCIAL_MANAGEMENT,
    DEPARTMENT_MANAGER,
    PHOTOGRAPHER,
}
