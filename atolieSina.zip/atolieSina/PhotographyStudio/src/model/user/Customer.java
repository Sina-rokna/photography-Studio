package model.user;
import model.product.Images;
import model.product.Products;
import model.product.Clips;

import java.util.ArrayList;

public class Customer extends User {
    private int CustomerId;
    private double balance;

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    private ArrayList<Clips> clips;
    private ArrayList<Images> images;
    private ArrayList<Products> boughtProducts;
    private ArrayList<Images> boughtImages;
    private ArrayList<Clips> boughtClips;

    public ArrayList<Products> getBoughtProducts() {
        return boughtProducts;
    }

    private Role role;

    private static int lastCustomerId;

    static {
        lastCustomerId = 0;
    }
    {
        balance = 0;
        images = new ArrayList<>();
        boughtProducts = new ArrayList<>();
        clips = new ArrayList<>();
        boughtClips = new ArrayList<>();
        boughtImages = new ArrayList<>();
    }
    public Customer(String username, String password){
        super(username , password);
        this.CustomerId = lastCustomerId;
        lastCustomerId++;
    }







}