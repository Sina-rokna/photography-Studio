package model.user;
public class User {
    private String name;
    private String username;
    private String password;
    private String email;
    private  int UserId ;
    private static int lastUserId;

    static {
        lastUserId = 0;
    }
    public User(String username, String password){
        this.username = username;
        this.password = password;
        this.UserId = lastUserId;
        lastUserId++;
    }


    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public static int getLastUserId() {
        return lastUserId;
    }
}
