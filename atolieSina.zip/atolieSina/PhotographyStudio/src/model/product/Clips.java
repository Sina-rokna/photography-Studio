package model.product;

public class Clips extends Products {
    private String duration;
    private String resolution;

    public Clips(String title, String locationOfWork , String photographerArtist, int price , int number, String duration , String resolution){
        super(title , locationOfWork , photographerArtist , price , number);
        this.duration = duration;
        this.resolution = resolution;
    }


    @Override
    public String chapgar(){
        return "Clip: "+ this.getTitle() +"  Price: " + this.getPrice() + "  Artist: "+ this.getPhotographerArtist();
    }
}
