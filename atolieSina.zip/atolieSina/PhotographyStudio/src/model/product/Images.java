package model.product;

public class Images extends Products{
    //sizeOfImage should be a String in x*y format. such as 20*30
    String sizeOfImage;
    public Images(String title, String locationOfWork , String photographerArtist, int price , int number, String sizeOfImage){
            super(title , locationOfWork, photographerArtist , price, number);
            this.sizeOfImage = sizeOfImage;
    }

    @Override
    public String chapgar(){
        return "Image: "+ this.getTitle() +"  Price: " + this.getPrice() + "  Artist: "+ this.getPhotographerArtist();
    }
}
