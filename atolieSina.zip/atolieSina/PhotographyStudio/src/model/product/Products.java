package model.product;
public class Products {
    private int productId;
    private String title;
    private String locationOfWork;
    private String photographerArtist;

    private int price;
    private int number;
    private static int lastProductId;
    static{
        lastProductId = 0;
    }
    public Products(String title, String locationOfWork , String photographerArtist, int price , int number){
        this.title = title;
        this.locationOfWork= locationOfWork;
        this.photographerArtist = photographerArtist;
        this.price = price;
        this.number = number;
        this.productId = lastProductId;
        lastProductId++;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public static void setLastProductId(int lastProductId) {
        Products.lastProductId = lastProductId;
    }

    public int getProductId() {
        return productId;
    }

    public String getTitle() {
        return title;
    }

    public int getPrice() {
        return price;
    }

    public String getPhotographerArtist() {
        return photographerArtist;
    }

    public int getNumber() {
        return number;
    }

    public static int getLastProductId() {
        return lastProductId;
    }
    public String chapgar() {
        return null;
    }
}
