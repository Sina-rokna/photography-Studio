package model;
import model.product.Products;
import model.user.User;
import java.util.ArrayList;
public class Studio {
    private static ArrayList<User> allUsers;
    private static ArrayList<Products> allProducts;
    //currentUser shows that who our user at this time for our program.
    private static User currentUser;
    static {
        allProducts = new ArrayList<>();
        allUsers = new ArrayList<>();
        currentUser = null;
    }
    public static User getUser(String username){
        if(allUsers.size() == 0){
            return null;
        }
        for(User user : allUsers){
            if(user.getUsername().equals(username))
                return user;
        }
        return null;
    }
    public static Products getProduct(String title){
        if(allProducts.size() == 0){
            return null;
        }
        for(Products Product: allProducts){
            if(Product.getTitle().equals(title))
                return Product;
        }
        return null;
    }

    public static ArrayList<User> getAllUsers() {
        return allUsers;
    }

    public static ArrayList<Products> getAllProducts() {
        return allProducts;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User currentUser) {
        Studio.currentUser = currentUser;
    }

    public static void setAllUsers(ArrayList<User> allUsers) {
        Studio.allUsers = allUsers;
    }
    public static void addUser(User user){
        allUsers.add(user);
    }
    public static void addProduct(Products product){
        allProducts.add(product);
    }
}
